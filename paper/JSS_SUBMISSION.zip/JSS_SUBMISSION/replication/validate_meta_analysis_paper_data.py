#!/usr/bin/env python3
"""
Meta-Analysis Validation - Using EXACT data from paper
======================================================
This script verifies the meta-analysis numbers using the EXACT data
shown in the paper (Section 10.3, Case Study 3).

The paper uses SIMULATED data (seed=561) to demonstrate Guardian's
publication bias detection capability. This script verifies that the
calculations are correct for the stated data.

Author: Vishal Bharti
Date: 2026-02-25
"""

import numpy as np
from scipy import stats

print("=" * 70)
print("META-ANALYSIS VERIFICATION - PAPER DATA")
print("=" * 70)
print("\nUsing EXACT data from paper Section 10.3...")
print("(Simulated with numpy.random.seed(561) as stated in paper)")

# EXACT data from paper lstlisting (Section 10.3)
effect_sizes = np.array([0.23, 0.15, 0.25, 0.35, 0.28, 0.28,
                         0.32, 0.42, 0.33, 0.28, 0.37, 0.31])
standard_errors = np.array([0.08, 0.04, 0.07, 0.06, 0.07, 0.08,
                            0.13, 0.14, 0.12, 0.13, 0.12, 0.14])

print(f"\nNumber of studies: {len(effect_sizes)}")
print(f"Effect sizes: {list(effect_sizes)}")
print(f"Standard errors: {list(standard_errors)}")

# Verify seed 561 reproduces this data
print("\n--- Seed Verification ---")
np.random.seed(561)
gen_eff = []
gen_se = []
for _ in range(6):
    s = round(np.random.uniform(0.04, 0.08), 2)
    e = round(0.25 + np.random.normal(0, 0.05), 2)
    gen_eff.append(e)
    gen_se.append(s)
for _ in range(6):
    s = round(np.random.uniform(0.10, 0.15), 2)
    e = round(0.25 + abs(np.random.normal(0, 0.08)), 2)
    gen_eff.append(e)
    gen_se.append(s)
gen_eff = np.array(gen_eff)
gen_se = np.array(gen_se)
effects_match = np.allclose(gen_eff, effect_sizes)
ses_match = np.allclose(gen_se, standard_errors)
print(f"Seed 561 reproduces effect sizes: {'PASS' if effects_match else 'FAIL'}")
print(f"Seed 561 reproduces standard errors: {'PASS' if ses_match else 'FAIL'}")

# Fixed-effect meta-analysis
print("\n--- Fixed-Effect Meta-Analysis ---")
weights = 1 / standard_errors**2
pooled_effect_fe = np.sum(weights * effect_sizes) / np.sum(weights)
pooled_se_fe = np.sqrt(1 / np.sum(weights))

print(f"Pooled effect: {pooled_effect_fe:.3f}")
print(f"Pooled SE: {pooled_se_fe:.3f}")

# Random-effects (DerSimonian-Laird)
print("\n--- Random-Effects Meta-Analysis (DerSimonian-Laird) ---")
Q = np.sum(weights * (effect_sizes - pooled_effect_fe)**2)
df = len(effect_sizes) - 1
C = np.sum(weights) - np.sum(weights**2) / np.sum(weights)
tau2 = max(0, (Q - df) / C)

weights_re = 1 / (standard_errors**2 + tau2)
pooled_effect_re = np.sum(weights_re * effect_sizes) / np.sum(weights_re)
pooled_se_re = np.sqrt(1 / np.sum(weights_re))

# I-squared
I2 = max(0, (Q - df) / Q * 100) if Q > 0 else 0

ci_lower = pooled_effect_re - 1.96 * pooled_se_re
ci_upper = pooled_effect_re + 1.96 * pooled_se_re

print(f"tau2: {tau2:.6f}")
print(f"Pooled effect (RE): {pooled_effect_re:.3f}")
print(f"Pooled SE (RE): {pooled_se_re:.3f}")
print(f"95% CI: [{ci_lower:.3f}, {ci_upper:.3f}]")
print(f"Heterogeneity: I2 = {I2:.1f}%, Q = {Q:.2f}")

# Egger's test for publication bias
print("\n--- Publication Bias: Egger's Test ---")
precision = 1 / standard_errors
standardized_effect = effect_sizes / standard_errors

slope, intercept, r_value, p_egger, std_err = stats.linregress(precision, standardized_effect)

print(f"Intercept: {intercept:.2f}")
print(f"Slope: {slope:.3f}")
print(f"p-value: {p_egger:.3f}")

if p_egger < 0.05:
    print("STATUS: WARNING - Significant funnel plot asymmetry")
    print("Suggests potential publication bias")
else:
    print("STATUS: No significant asymmetry detected")

# Compare with paper claims
print("\n" + "=" * 70)
print("COMPARISON: Paper vs Calculated")
print("=" * 70)

paper_values = {
    'pooled_effect': 0.263,
    'ci_lower': 0.213,
    'ci_upper': 0.314,
    'I2': 14.4,
    'Q': 12.85,
    'egger_intercept': 1.84,
    'egger_p': 0.024
}

calculated = {
    'pooled_effect': round(pooled_effect_re, 3),
    'ci_lower': round(ci_lower, 3),
    'ci_upper': round(ci_upper, 3),
    'I2': round(I2, 1),
    'Q': round(Q, 2),
    'egger_intercept': round(intercept, 2),
    'egger_p': round(p_egger, 3)
}

all_pass = True
print(f"\n{'Metric':<20} {'Paper':<12} {'Calculated':<12} {'Match?':<10}")
print("-" * 55)
for key in paper_values:
    pval = paper_values[key]
    cval = calculated[key]
    match = abs(pval - cval) < max(0.01, abs(pval) * 0.05)
    status = "PASS" if match else "FAIL"
    if not match:
        all_pass = False
    print(f"{key:<20} {pval:<12.3f} {cval:<12.3f} {status:<10}")

print("\n" + "=" * 70)
print("OVERALL RESULT")
print("=" * 70)
if all_pass:
    print("ALL CHECKS PASSED - Paper values match computed results.")
else:
    print("SOME CHECKS FAILED - Review mismatches above.")
print()
